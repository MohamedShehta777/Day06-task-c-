﻿
using System;

#region Part01 - Problem 1: Create a struct Point
using System;

struct Point
{
    public int X { get; set; }
    public int Y { get; set; }

    public Point()
    {
        X = 0;
        Y = 0;
    }

    public Point(int x, int y)
    {
        X = x;
        Y = y;
    }

    public override string ToString()
    {
        return $"({X}, {Y})";
    }
}

// Question: Why can't a struct inherit from another struct or class in C#?
// Answer: In C#, structs are value types and are designed for lightweight objects. They implicitly inherit from System.ValueType and cannot inherit from other structs or classes to preserve simplicity and avoid the complexities of multiple inheritance.

#endregion

#region Part01 - Problem 2: Create a class TypeA
class TypeA
{
    private int F;
    internal int G;
    public int H;

    public TypeA()
    {
        F = 10;
        G = 20;
        H = 30;
    }

    public int GetPrivateF() => F;
}

class Program2
{
    static void Main()
    {
        TypeA obj = new TypeA();
        Console.WriteLine($"H (Public): {obj.H}");
        Console.WriteLine($"G (Internal): {obj.G}");
        Console.WriteLine($"F (Private via method): {obj.GetPrivateF()}");
    }
}

// Question: How do access modifiers impact the scope and visibility of a class member?
// Answer: Access modifiers define how and where a class member can be accessed. 
// - `private`: Only accessible within the same class.
// - `internal`: Accessible within the same assembly.
// - `public`: Accessible from anywhere.

#endregion

#region Part01 - Problem 3: Define a struct Employee
struct Employee
{
    private int EmpId;
    private string Name;
    private double Salary;

    public Employee(int empId, string name, double salary)
    {
        EmpId = empId;
        Name = name;
        Salary = salary;
    }

    public string GetName() => Name;
    public void SetName(string name) => Name = name;

    public override string ToString()
    {
        return $"Employee [ID: {EmpId}, Name: {Name}, Salary: {Salary}]";
    }
}

class Program3
{
    static void Main()
    {
        Employee emp = new Employee(1, "John", 50000);
        Console.WriteLine(emp);
        emp.SetName("Jane");
        Console.WriteLine($"Updated Name: {emp.GetName()}");
    }
}

// Question: Why is encapsulation critical in software design?
// Answer: Encapsulation promotes modularity, restricts direct access to data, and provides controlled mechanisms for modification, improving maintainability and security.

#endregion

#region Part01 - Problem 4: Constructor overloading in Point struct
struct PointOverload
{
    public int X { get; set; }
    public int Y { get; set; }

    public PointOverload(int x)
    {
        X = x;
        Y = 0;
    }

    public PointOverload(int x, int y)
    {
        X = x;
        Y = y;
    }
}

class Program4
{
    static void Main()
    {
        PointOverload p1 = new PointOverload(5);
        PointOverload p2 = new PointOverload(10, 20);
        Console.WriteLine($"Point 1: ({p1.X}, {p1.Y})");
        Console.WriteLine($"Point 2: ({p2.X}, {p2.Y})");
    }
}

// Question: What are constructors in structs?
// Answer: Constructors in structs initialize the data members when an object is created. They can be parameterized but cannot have a parameterless default constructor unless explicitly defined.

#endregion

#region Part01 - Problem 5: Modify ToString() for Point struct
struct PointFormatted
{
    public int X { get; set; }
    public int Y { get; set; }

    public PointFormatted(int x, int y)
    {
        X = x;
        Y = y;
    }

    public override string ToString()
    {
        return $"Point: X={X}, Y={Y}";
    }
}

class Program5
{
    static void Main()
    {
        PointFormatted p1 = new PointFormatted(3, 4);
        PointFormatted p2 = new PointFormatted(10, 20);
        Console.WriteLine(p1);
        Console.WriteLine(p2);
    }
}

// Question: How does overriding methods like ToString() improve code readability?
// Answer: Overriding ToString() provides meaningful string representations of objects, enhancing readability and simplifying debugging.

#endregion

#region Part01 - Problem 6: Value vs Reference types
struct ValuePoint
{
    public int X { get; set; }
    public int Y { get; set; }
}

class EmployeeRef
{
    public string Name { get; set; }
    public double Salary { get; set; }
}

class Program6
{
    static void ModifyStruct(ValuePoint point)
    {
        point.X = 100;
        point.Y = 200;
    }

    static void ModifyClass(EmployeeRef emp)
    {
        emp.Name = "Updated Name";
        emp.Salary = 99999;
    }

    static void Main()
    {
        ValuePoint vp = new ValuePoint { X = 1, Y = 2 };
        EmployeeRef er = new EmployeeRef { Name = "John", Salary = 50000 };

        Console.WriteLine($"Before Modification - Struct: ({vp.X}, {vp.Y})");
        ModifyStruct(vp);
        Console.WriteLine($"After Modification - Struct: ({vp.X}, {vp.Y})");

        Console.WriteLine($"Before Modification - Class: {er.Name}, Salary: {er.Salary}");
        ModifyClass(er);
        Console.WriteLine($"After Modification - Class: {er.Name}, Salary: {er.Salary}");
    }
}

// Question: How does memory allocation differ for structs and classes in C#?
// Answer: Structs are stored on the stack, making them more efficient for small data sets. Classes are stored on the heap and accessed by references, allowing greater flexibility for complex objects.

#endregion
